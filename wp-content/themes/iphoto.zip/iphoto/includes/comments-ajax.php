<?php

if ( 'POST'!= $_SERVER['REQUEST_METHOD'] ) {
header('Allow: POST');
header('HTTP/1.1 405 Method Not Allowed');
header('Content-Type: text/plain');
exit;
}
require_once(dirname(__FILE__).'/../../../../wp-load.php');
nocache_headers();
$comment_post_ID = isset($_POST['comment_post_ID']) ?(int) $_POST['comment_post_ID'] : 0;
$post = get_post($comment_post_ID);
$status = get_post_status($post);
$status_obj = get_post_status_object($status);
do_action('pre_comment_on_post',$comment_post_ID);
$comment_author       = ( isset($_POST['author']) )  ?trim(strip_tags($_POST['author'])) : null;
$comment_author_email = ( isset($_POST['email']) )   ?trim($_POST['email']) : null;
$comment_author_url   = ( isset($_POST['url']) )     ?trim($_POST['url']) : null;
$comment_content      = ( isset($_POST['comment']) ) ?trim($_POST['comment']) : null;
$edit_id              = ( isset($_POST['edit_id']) ) ?$_POST['edit_id'] : null;
$headers=@get_headers('http://1.gravatar.com/avatar/'.md5(strtolower($comment_author_email)).'?d=404');
if(strstr($headers[0],'404') && !is_user_logged_in())
    err('Error: gravatar not existed (check your email address).');
$user = wp_get_current_user();
if ( $user->ID ) {
if ( empty( $user->display_name ) )
$user->display_name=$user->user_login;
$comment_author       = $wpdb->escape($user->display_name);
$comment_author_email = $wpdb->escape($user->user_email);
$comment_author_url   = $wpdb->escape($user->user_url);
if ( current_user_can('unfiltered_html') ) {
if ( wp_create_nonce('unfiltered-html-comment_'.$comment_post_ID) != $_POST['_wp_unfiltered_html_comment'] ) {
kses_remove_filters();
kses_init_filters();
}
}
}else {
if ( get_option('comment_registration') ||'private'== $status )
err(__('Sorry, you must be logged in to post a comment.'));
}
$comment_type = '';
if ( get_option('require_name_email') &&!$user->ID ) {
if ( 6 >strlen($comment_author_email) ||''== $comment_author )
err( __('Error: please fill the required fields (name, email).') );
elseif ( !is_email($comment_author_email))
err( __('Error: please enter a valid email address.') );
}
if ( ''== $comment_content )
err( __('Error: please type a comment.') );
function err($ErrMsg) {
header('HTTP/1.1 405 Method Not Allowed');
echo $ErrMsg;
exit;
}
$comment_parent = isset($_POST['comment_parent']) ?absint($_POST['comment_parent']) : 0;
$commentdata = compact('comment_post_ID','comment_author','comment_author_email','comment_author_url','comment_content','comment_type','comment_parent','user_ID');
if ( $edit_id ){
$comment_id = $commentdata['comment_ID'] = $edit_id;
wp_update_comment( $commentdata );
}else {
$comment_id = wp_new_comment( $commentdata );
}
$comment = get_comment($comment_id);
if ( !$user->ID ) {
$comment_cookie_lifetime = apply_filters('comment_cookie_lifetime',30000000);
setcookie('comment_author_'.COOKIEHASH,$comment->comment_author,time() +$comment_cookie_lifetime,COOKIEPATH,COOKIE_DOMAIN);
setcookie('comment_author_email_'.COOKIEHASH,$comment->comment_author_email,time() +$comment_cookie_lifetime,COOKIEPATH,COOKIE_DOMAIN);
setcookie('comment_author_url_'.COOKIEHASH,esc_url($comment->comment_author_url),time() +$comment_cookie_lifetime,COOKIEPATH,COOKIE_DOMAIN);
}
$comment_depth = 1;
$tmp_c = $comment;
while($tmp_c->comment_parent != 0){
$comment_depth++;
$tmp_c = get_comment($tmp_c->comment_parent);
}
;echo '<li ';comment_class('clearfix');;echo ' id="comment-';comment_ID() ;echo '" style="margin-top:1em;">
	<div id="div-comment-';comment_ID();;echo '" class="comment-body live">
	<div class="commentmeta">';echo get_avatar( $comment,$size = '48');;echo '</div>
	';if ($comment->comment_approved == '0') : ;echo '		<em>';_e('Your comment is awaiting moderation.') ;echo '</em><br />
	';endif;;echo '	<div class="vcard">';printf(__('%s'),get_comment_author_link()) ;echo '</div>
	';comment_text() ;echo '</div>';?>